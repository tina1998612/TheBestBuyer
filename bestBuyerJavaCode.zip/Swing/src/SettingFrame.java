import javax.swing.*;

/**
 * Created by lenovo on 2017/4/22.
 */
public class SettingFrame extends JFrame{
    public SettingFrame(){
        super("Snap Check");
        setSize(600,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
